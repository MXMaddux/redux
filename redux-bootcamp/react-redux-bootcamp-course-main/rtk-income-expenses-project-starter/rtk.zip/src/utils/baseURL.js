const baseURL = "https://income-expenses-tracker-web-dev.onrender.com/api/v1";

export default baseURL;
